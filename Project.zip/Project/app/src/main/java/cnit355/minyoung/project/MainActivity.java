package cnit355.minyoung.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    Button btnSpin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void SpinTheBottle(View view) {
        Intent mIntent = new Intent(this, bottle.class);
        startActivity(mIntent);
    }

    public void RandomBox(View view) {
        Intent mIntent = new Intent(this, RandomBox.class);
        startActivity(mIntent);

    }

    public void TimeAttack(View view) {
        Intent mIntent = new Intent(this, TimeAttack.class);
        startActivity(mIntent);
    }


    public void King(View view) {
        Intent mIntent = new Intent(this, King.class);
        startActivity(mIntent);
    }
}
