package cnit355.minyoung.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;



public class TimeAttack extends AppCompatActivity {
    private static final long START_TIME_IN_MILLIS = 60000;

    private TextView mTextViewCountDown;
    private Button mButtonStartPause;
    private Button mButtonReset;
    private  ImageView mImageView;
    private CountDownTimer mCountDownTimer;

    private boolean mTimerRunning;

    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;

    MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_attack);


            player = MediaPlayer.create(TimeAttack.this,R.raw.alert);

            mTextViewCountDown = findViewById(R.id.text_view_countdown);

            mButtonStartPause = findViewById(R.id.button_start_pause);

            mButtonReset = findViewById(R.id.button_reset);

            mButtonStartPause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mTimerRunning){
                        pauseTimer();
                    }else{
                        startTimer();
                    }
                }
            });


            mButtonReset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    resetTimer();
                }
            });

            updateCountDownText();

            mImageView = findViewById(R.id.imageView);


        }


        private void startTimer(){
            mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    mTimeLeftInMillis = millisUntilFinished;
                    updateCountDownText();
                }

                @Override
                public void onFinish() {
                    mTimerRunning = false;
                    mButtonStartPause.setText("start");
                    String ENDtimeLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d", 0, 0);
                    mTextViewCountDown.setText(ENDtimeLeftFormatted);
                    mButtonStartPause.setVisibility(View.INVISIBLE);
                    mButtonReset.setVisibility(View.VISIBLE);
                    Drawable myDrawable = ResourcesCompat.getDrawable(getResources(),R.drawable.bomb_after,null);
                    mImageView.setImageDrawable(myDrawable);

                    Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                    vib.vibrate(1500); //add vibration

                    player.start();
                    player.setLooping(true);  //add alert sound
                }
            }.start();

            mTimerRunning = true;
            mButtonStartPause.setText("Pause");
            mButtonReset.setVisibility(View.INVISIBLE);
        }

        private void pauseTimer(){
            mCountDownTimer.cancel();
            mTimerRunning = false;
            mButtonStartPause.setText("Start");
            mButtonReset.setVisibility(View.VISIBLE);
        }
        private void resetTimer(){
            mTimeLeftInMillis = START_TIME_IN_MILLIS;
            updateCountDownText();
            mButtonReset.setVisibility(View.INVISIBLE);
            mButtonStartPause.setVisibility(View.VISIBLE);
            Drawable myDrawable2 = ResourcesCompat.getDrawable(getResources(),R.drawable.bomb_before,null);
            mImageView.setImageDrawable(myDrawable2);
            player.stop();
        }

        private void updateCountDownText(){
            int minutes = (int)(mTimeLeftInMillis/1000) / 60;
            int seconds = (int)(mTimeLeftInMillis/1000) % 60;


            String timeLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d", minutes, seconds);
            mTextViewCountDown.setText(timeLeftFormatted);
        }


    }
