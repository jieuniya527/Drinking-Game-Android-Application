package cnit355.minyoung.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


public class King extends AppCompatActivity {
    public void Again(View view){

        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
    int num = ((int) (Math.random() * 12)) + 1;

    Drawable mDrawable;
    ImageButton mButton5;
    ImageButton mButton6;
    ImageButton mButton7;
    ImageButton mButton8;
    ImageButton mButton9;
    ImageButton mButton10;
    ImageButton mButton11;
    ImageButton mButton12;
    ImageButton mButton13;
    ImageButton mButton14;
    ImageButton mButton15;
    ImageButton mButton16;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_king);

        mButton5 =findViewById(R.id.button5);
        mButton6=findViewById(R.id.button6);
        mButton7=findViewById(R.id.button7);
        mButton8=findViewById(R.id.button8);
        mButton9=findViewById(R.id.button9);
        mButton10=findViewById(R.id.button10);
        mButton11=findViewById(R.id.button11);
        mButton12=findViewById(R.id.button12);
        mButton13=findViewById(R.id.button13);
        mButton14=findViewById(R.id.button14);
        mButton15=findViewById(R.id.button15);
        mButton16=findViewById(R.id.button16);
        Intent mIntent = getIntent();

        if (mIntent == null) {
            return;
        }
        String qString = mIntent.getStringExtra("qString");
        TextView textView3 = (TextView)findViewById(R.id.textView3);
        textView3.setText(qString);
    }

    public void  MoveToMainActivity(View view){
        finish();
    }

    public void ClickMethod(View view) {
        switch (view.getId()) {
            case R.id.button5:
                if (num == 1) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton5.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton5.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button6:
                if (num == 2) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton6.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Drink!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton6.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button7:
                if (num == 3) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton7.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Drink!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton7.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button8:
                if (num == 4) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton8.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton8.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button9:
                if (num == 5) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton9.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton9.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button10:
                if (num == 6) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton10.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton10.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button11:
                if (num == 7) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton11.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton11.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button12:
                if (num == 8) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton12.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton12.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button13:
                if (num == 9) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton13.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton13.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button14:
                if (num == 10) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton14.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton14.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button15:
                if (num == 11) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton15.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton15.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
            case R.id.button16:
                if (num == 12) {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.king, null);
                    mButton16.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "You are the King!", Toast.LENGTH_SHORT).show();
                }
                else {
                    mDrawable = ResourcesCompat.getDrawable(getResources(), R.drawable.card, null);
                    mButton16.setImageDrawable(mDrawable);
                    Toast.makeText(getApplicationContext(), "Nothing happened!", Toast.LENGTH_SHORT).show();
                }break;
        }
    }

}

