package cnit355.minyoung.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

// Part of code source https://stackoverflow.com/questions/15083811/programmatically-rotate-drawable-or-view
// Part of code source https://stackoverflow.com/questions/8981845/android-rotate-image-in-imageview-by-an-angle
public class bottle extends AppCompatActivity {
    ImageView bottle;
    Button Spin;
    Random r;
    int angle;
    Button back;
    boolean restart = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottle);
        Intent mIntent = getIntent();
        if (mIntent == null) {
            return;
        }

        r = new Random();

        bottle = (ImageView) findViewById(R.id.bottle);


        bottle = (ImageView) findViewById(R.id.bottle);
        Spin = (Button) findViewById(R.id.Spin);
        back = (Button) findViewById(R.id.back);

        Spin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (restart) {
                    int temp = angle % 360;
                    RotateAnimation rotate = new RotateAnimation(temp, 0, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
                    rotate.setFillAfter(true);
                    bottle.startAnimation(rotate);
                    restart = false;
                    Spin.setText("SPIN");
                } else {
                    angle = r.nextInt(2000) + 360;
                    RotateAnimation rotate = new RotateAnimation(0, angle, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
                    rotate.setFillAfter(true);
                    rotate.setDuration(3600);
                    bottle.startAnimation(rotate);


                    restart = true;
                    Spin.setText("RESET");
               }
            }

        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }

        });
    }
}
