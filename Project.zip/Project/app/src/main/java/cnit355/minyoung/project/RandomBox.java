package cnit355.minyoung.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

//part of code source: https://github.com/h3lboy/RandomQuestions

public class RandomBox extends AppCompatActivity {
    Button back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_box);
        back = (Button) findViewById(R.id.back);
        final Button btn_Open;
        final Button btn_restart;
        final EditText edit_Tasks;
        final ImageView image;

            btn_Open = findViewById(R.id.btn_Open);
            btn_restart = findViewById(R.id.btn_restart);
            edit_Tasks = findViewById(R.id.editText);
            image = findViewById(R.id.box);


            final String tasks[] = {
                    "Love shot with the person next to you!",
                    "Dance in front of everyone!",
                    "Take a shot!!",
                    "Sing a song!",
                    "Pick someone to drink",
                    "Drink all the drinks in front of you!",
                    "Drink 2 shots!",
                    "Make someone next to you laugh!",
                    "Dip a snack into a drink and eat it!",
                    "Get ticked for 10 seconds!",
                    "Hug someone next to you!"



            };


            btn_Open.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Random rand = new Random();
                    int task = rand.nextInt(10);

                    edit_Tasks.setVisibility(View.VISIBLE);
                    image.setVisibility(View.INVISIBLE);
                    edit_Tasks.setText(tasks[task]);
                    btn_restart.setVisibility(View.VISIBLE);
                    btn_Open.setText("Reroll");
                }
            });

            btn_restart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    btn_restart.setVisibility(View.INVISIBLE);
                    btn_Open.setText("Open Random Box");
                    image.setVisibility(View.VISIBLE);
                }
            });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }

        });
        }

    }
